﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZeldaFullEditor
{
    public static class Constants
    {
        public static int tile_address = 0x1B52; // JP = Same
        public static int subtype1_tiles = 0x8000; // JP = Same
        public static int subtype2_tiles = 0x83F0; // JP = Same
        public static int subtype3_tiles = 0x84F0; // JP = Same
        public static int gfx_pointer_1 = 0x4F80; //JP = 0x4FC0  /  0x509F / 0x517E
        public static int gfx_pointer_2 = 0x505F;
        public static int gfx_pointer_3 = 0x513E;
        public static int dungeons_palettes_groups = 0x75460; //JP 0x67DD0
        public static int dungeons_main_bg_palette_pointers = 0xDEC4B; //JP Sane
        public static int dungeons_palettes = 0xDD734; //JP Same (where all dungeons palettes are) 
        public static int room_object_pointers = 0xF8000; //JP Same (3 bytes LONG pointer)
        public static int room_object_layout_pointers = 0x26F2F; //JP 0x26C0F
        public static int room_items_pointers = 0xDB69;//JP 0xDB67
        public static int room_sprites_pointers = 0x4D62E; //JP same
        public static int room_header_pointers = 0x27502; //JP 0x271E2
        public static int room_header_pointers_bank = 0xB5E7; //JP Same
        //TODO : On ROM Load if Pointers are at original location
        //Expand ROM to 2MB if US, 4MB if VT, move Headers to new location
         


        public static void Init_Jp()
        {
            gfx_pointer_1 = 0x4FC0;
            gfx_pointer_2 = 0x509F;
            gfx_pointer_3 = 0x517E;
            dungeons_palettes_groups = 0x67DD0;
            room_items_pointers = 0xDB67;
            room_object_layout_pointers = 0x26C0F;
            room_header_pointers = 0x271E2;

        }


    }
}
