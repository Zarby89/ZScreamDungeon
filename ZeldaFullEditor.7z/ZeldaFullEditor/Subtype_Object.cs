﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ZeldaFullEditor
{
    public class Subtype_Object
    {
        public byte x, y; //position of the object in the room (*8 for draw)
        public byte size; //size of the object
        public bool allBgs = false; //if the object is drawn on BG1 and BG2 regardless of type of BG
        public List<Tile> tiles = new List<Tile>();
        public short id; 
        public string name; //name of the object will be shown on the form
        public Subtype_Object(short id,byte x,byte y,byte size)
        {
            this.x = x;
            this.y = y;
            this.size = size;
            //size++;
            this.id = id;
            //init_objects();

        }

        public virtual void Draw()
        {
             
        }

        public void addTiles(int nbr,int pos)
        {
            for(int i = 0;i<nbr;i++)
            {
                tiles.Add(new Tile(ROM.DATA[pos + ((i * 2))], ROM.DATA[pos + ((i * 2)) +1]));
            }
        }


        //Object Initialization (Tiles and special stuff)
        public void init_objects()
        {
            int pos = 0;
            byte oid = (byte)(id & 0xFF); //id
            if ((id & 0x100) == 0x100) //subtype2
            {
                pos = Constants.tile_address + ((ROM.DATA[Constants.subtype3_tiles + (oid * 2) + 1] << 8) + ROM.DATA[Constants.subtype3_tiles + (oid * 2)]);

            }
            else if ((id & 0xF00) == 0xF00)//subtype3
            {
                pos = Constants.tile_address + ((ROM.DATA[Constants.subtype2_tiles + (oid * 2) + 1] << 8) + ROM.DATA[Constants.subtype2_tiles + (oid * 2)]);
             

            }

            

            if (id == 0x03)//0 - 15
            {
                //2x4 b
                addTiles(8, pos);
                allBgs = true;
                name = "Top Wall (Lower)";
            }
            else if (id == 0x04)//0 - 15
            {
                //2x4 b
                addTiles(8, pos);
                allBgs = true;
                name = "Bottom Wall (Lower)";
            }
            else if (id == 0x05)//0 - 15 (skip 4 tile between draw)
            {
                //2x4
                addTiles(8, pos);
                name = "Top Column";
            }
            else if (id == 0x06)//0 - 15 (skip 4 tile between draw)
            {
                //2x4
                addTiles(8, pos);
                name = "Bottom Column";
            }
            else if (id == 0x07)//0 - 15
            {
                //2x2 
                addTiles(4, pos);
                name = "Top Pit Edge";
            }
            else if (id == 0x08)//0 - 15
            {
                //2x2 
                addTiles(4, pos);
                name = "Bottom Pit Edge";
            }
            else if (id == 0x09)//0 - 15 (Draw: (SizeX+7) every X: Y-=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Top Left";
            }
            else if (id == 0x0A)//0 - 15 (Draw: (SizeX+7) every X: Y+=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Bottom Left";
            }
            else if (id == 0x0B)//0 - 15 (Draw: (SizeX+7) every X: Y+=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Top Right";
            }
            else if (id == 0x0C)//0 - 15 (Draw: (SizeX+7) every X: Y-=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Bottom Right";
            }
            else if (id == 0x0D)//0 - 15 (Draw: (SizeX+7) every X: Y-=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Top Left Alt1";
            }
            else if (id == 0x0E)//0 - 15 (Draw: (SizeX+7) every X: Y+=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Bottom Left Alt1";
            }
            else if (id == 0x0F)//0 - 15 (Draw: (SizeX+7) every X: Y+=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Top Right Alt1";
            }
            else if (id == 0x10)//0 - 15 (Draw: (SizeX+7) every X: Y-=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Bottom Right Alt1";
            }
            else if (id == 0x11)//0 - 15 (Draw: (SizeX+7) every X: Y-=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Top Left Alt2";
            }
            else if (id == 0x12)//0 - 15 (Draw: (SizeX+7) every X: Y+=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Bottom Left Alt2";
            }
            else if (id == 0x13)//0 - 15 (Draw: (SizeX+7) every X: Y+=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Top Right Alt2";
            }
            else if (id == 0x14)//0 - 15 (Draw: (SizeX+7) every X: Y-=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Bottom Right Alt2";
            }
            else if (id == 0x15)//0 - 15 (Draw: (SizeX+7) every X: Y-=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Top Left (Lower)";
            }
            else if (id == 0x16)//0 - 15 (Draw: (SizeX+7) every X: Y+=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Bottom Left (Lower)";
            }
            else if (id == 0x17)//0 - 15 (Draw: (SizeX+7) every X: Y+=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Top Right (Lower)";
            }
            else if (id == 0x18)//0 - 15 (Draw: (SizeX+7) every X: Y-=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Bottom Right (Lower)";
            }
            else if (id == 0x19)//0 - 15 (Draw: (SizeX+7) every X: Y-=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Top Left Alt1 (Lower)";
            }
            else if (id == 0x1A)//0 - 15 (Draw: (SizeX+7) every X: Y+=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Bottom Left Alt1 (Lower)";
            }
            else if (id == 0x1B)//0 - 15 (Draw: (SizeX+7) every X: Y+=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Top Right Alt1 (Lower)";
            }
            else if (id == 0x1C)//0 - 15 (Draw: (SizeX+7) every X: Y-=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Bottom Right Alt1 (Lower)";
            }
            else if (id == 0x1D)//0 - 15 (Draw: (SizeX+7) every X: Y-=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Top Left Alt2 (Lower)";
            }
            else if (id == 0x1E)//0 - 15 (Draw: (SizeX+7) every X: Y+=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Bottom Left Alt2 (Lower)";
            }
            else if (id == 0x1F)//0 - 15 (Draw: (SizeX+7) every X: Y+=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Top Right Alt2 (Lower)";
            }
            else if (id == 0x20)//0 - 15 (Draw: (SizeX+7) every X: Y-=1)
            {
                addTiles(5, pos);
                name = "Diag. Wall Bottom Right Alt2 (Lower)";
            }
            else if (id == 0x21)//0 - 15 (Draw: Column1+Colomn2  Column2+Column2  Column2+Column3)
            {
                addTiles(9, pos);
                name = "Mini Stairs";
            }
            else if (id == 0x22)//0 - 15 (size+2, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Small Horiz. Rail";
            }
            else if (id == 0x23)//0 - 15 (size+1, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Top Hole Cornered Edge";
            }
            else if (id == 0x24)//0 - 15 (size+1, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Top Hole Edge Cornered (Duplicate)";
            }
            else if (id == 0x25)//0 - 15 (size+1, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Top Hole Edge Cornered (Duplicate)";
            }
            else if (id == 0x26)//0 - 15 (size+1, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Top Hole Edge Cornered (Duplicate)";
            }
            else if (id == 0x27)//0 - 15 (size+1, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Top Hole Edge Cornered (Duplicate)";
            }
            else if (id == 0x28)//0 - 15 (size+1, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Bottom Hole Cornered Edge";
            }
            else if (id == 0x29)//0 - 15 (size+1, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Bottom Hole Edge";
            }
            else if (id == 0x2A)//0 - 15 (size+1, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Top Hole Edge";
            }
            else if (id == 0x2B)//0 - 15 (size+1, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Bottom Right Hole Edge";
            }
            else if (id == 0x2C)//0 - 15 (size+1, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Bottom Left Hole Edge";
            }
            else if (id == 0x2D)//0 - 15 (size+1, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Top Right Hole Edge";
            }
            else if (id == 0x2E)//0 - 15 //rail bridge use old draw...
            {
                addTiles(3, pos);
                name = "Top Left Hole Edge";
            }
            else if (id == 0x2F)//0 - 15 //rail bridge use old draw...
            {
                addTiles(6, pos);
                name = "Horiz. Top Rail Bridge";
            }
            else if (id == 0x30)//0 - 15 //rail bridge use old draw...
            {
                addTiles(6, pos);
                name = "Horiz. Bottom Rail Bridge";
            }
            else if (id == 0x33)//0 - 15 floor
            {
                addTiles(16, pos);
                name = "Floor plain color";
            }
            else if (id == 0x34)//0 - 15 floor
            {
                addTiles(1, pos);
                name = "Carpet Corner";
            }
            else if (id == 0x36)//0 - 15 floor skip 2 tile on scale
            {
                addTiles(16, pos);
                name = "Curtain";
            }
            else if (id == 0x37)//0 - 15 floor skip 2 tile on scale
            {
                addTiles(16, pos);
                name = "Weird Curtain";
            }
            else if (id == 0x38)//0 - 15 floor skip 2 tile on scale
            {
                addTiles(6, pos);
                name = "Statue";
            }
            else if (id == 0x39)//0 - 15 floor skip 4 tile on scale
            {
                addTiles(8, pos);
                name = "Column";
            }
            else if (id == 0x3A)//0 - 15 floor skip 4 tile on scale
            {
                addTiles(12, pos);
                name = "Top Wall Decoration";
            }
            else if (id == 0x3B)//0 - 15 floor skip 4 tile on scale
            {
                addTiles(12, pos);
                name = "Bottom Wall Decoration";
            }
            else if (id == 0x3C)//0 - 15 (skip 2 tiles) //use old draw code
            {
                addTiles(4, pos);
                name = "Double Chair";
            }
            else if (id == 0x3D)//0 - 15 floor skip 4 tile on scale
            {
                addTiles(8, pos);
                name = "Floor Torch";
            }
            else if (id == 0x3E)//0 - 15 floor skip 8 tile on scale?
            {
                addTiles(4, pos);
                name = "Top Column?";
            }
            else if (id == 0x3F)//0 - 15 floor skip tile on scale? //same as pit edge
            {
                addTiles(3, pos);
                name = "Water Edge";
            }
            else if (id == 0x40)//0 - 15 floor skip tile on scale? //same as pit edge
            {
                addTiles(3, pos);
                name = "Water Edge";
            }
            else if (id == 0x41)//0 - 15 floor skip tile on scale? //same as pit edge
            {
                addTiles(3, pos);
                name = "Water Edge";
            }
            else if (id == 0x42)//0 - 15 floor skip tile on scale? //same as pit edge
            {
                addTiles(3, pos);
                name = "Water Edge";
            }
            else if (id == 0x43)//0 - 15 floor skip tile on scale? //same as pit edge
            {
                addTiles(3, pos);
                name = "Water Edge";
            }
            else if (id == 0x44)//0 - 15 floor skip tile on scale? //same as pit edge
            {
                addTiles(3, pos);
                name = "Water Edge";
            }
            else if (id == 0x45)//0 - 15 floor skip tile on scale? //same as pit edge
            {
                addTiles(3, pos);
                name = "Water Edge";
            }
            else if (id == 0x46)//0 - 15 floor skip tile on scale? //same as pit edge
            {
                addTiles(3, pos);
                name = "Water Edge";
            }
            else if (id == 0x49)//0 - 15
            {
                addTiles(8, pos);
                name = "????";
            }
            else if (id == 0x4A)//0 - 15
            {
                addTiles(8, pos);
                name = "????";
            }
            else if (id == 0x4B)//0 - 15 floor skip 8 tile on scale?
            {
                addTiles(4, pos);
                name = "Top Column?";
            }
            else if (id == 0x4C)//0 - 15 (Draw: Column1+Colomn2  Column2+Column2  Column2+Column3)
            {
                addTiles(9, pos);
                name = "Bar";
            }
            else if (id == 0x4D)//0 - 15 (Draw: Column1+Colomn2  Column2+Column2  Column2+Column3)
            {
                addTiles(16, pos);
                name = "Wall Shelf";
            }
            else if (id == 0x4E)//0 - 15 (Draw: Column1+Colomn2  Column2+Column2  Column2+Column3)
            {
                addTiles(16, pos);
                name = "Wall Shelf";
            }
            else if (id == 0x4F)//0 - 15 (Draw: Column1+Colomn2  Column2+Column2  Column2+Column3)
            {
                addTiles(16, pos);
                name = "Wall Shelf";
            }
            else if (id == 0x50)//HEX : 0x50 //0 - 15 (sizeX+1 Draw: Column1)
            {
                addTiles(1, pos);
                name = "???";
            }
            else if (id == 0x51)//0 - 15 (Draw: Column1+Colomn2  Column2+Column2  Column2+Column3)
            {
                addTiles(18, pos);
                name = "???";
            }
            else if (id == 0x52)//0 - 15 (Draw: Column1+Colomn2  Column2+Column2  Column2+Column3)
            {
                addTiles(18, pos);
                name = "???";
            }
            else if (id == 0x53)//0 - 15
            {
                addTiles(4, pos);
                name = "???";
            }
            else if (id == 0x55)//0 - 15 skip 8 tiles
            {
                addTiles(8, pos);
                name = "Top Wall Torch";
            }
            else if (id == 0x56)//0 - 15 skip 8 tiles
            {
                addTiles(8, pos);
                name = "Bottom Wall Torch";
            }
            else if (id == 0x5B)//0 - 15 (Draw: Column1+Colomn2  Column2+Column2  Column2+Column3)
            {
                addTiles(18, pos);
                name = "???";
            }
            else if (id == 0x5C)//0 - 15 (Draw: Column1+Colomn2  Column2+Column2  Column2+Column3)
            {
                addTiles(18, pos);
                name = "???";
            }
            else if (id == 0x5D)//0 - 15 (Draw: skip 2 tiles)
            {
                addTiles(15, pos);
                name = "Horiz. Big Rail";
            }
            else if (id == 0x5E)//0 - 15 (size+15, column1+column2 column2 column2+colum3)
            {
                addTiles(4, pos);
                name = "Horiz. Block";
            }
            else if (id == 0x5F)//0 - 15 (size+15, column1+column2 column2 column2+colum3)
            {
                addTiles(3, pos);
                name = "Long Horiz. Rail";
            }

            //START OF THE VERTICAL OBJECTS
            /*else if (oid == 0x60)//0 - 15 (size+15, column1+column2 column2 column2+colum3)
            {
                tsizeX = 3;
                tsizeY = 1;
                name = "Long Horiz. Rail";
            }*/

    }

        //tile order is 1 4 7
        //              2 5 8
        //              3 6 9
        //Objects Draw


        public void draw_tile(Tile t, int x, int y)
        {
            Bitmap b = new Bitmap(8, 8);


            int ty = (t.id / 16);
            int tx = t.id - (ty * 16);
            using (Graphics g = Graphics.FromImage(b))
            {
                g.DrawImage(GFX.blocksets[t.palette], new Rectangle(0, 0, 8, 8), tx * 8, ty * 8, 8, 8, GraphicsUnit.Pixel);
            }


            if (t.mirror_x) //mirror x
                b.RotateFlip(RotateFlipType.RotateNoneFlipX);
            if (t.mirror_y) //mirror y
                b.RotateFlip(RotateFlipType.RotateNoneFlipY);

            GFX.graphic.DrawImage(b, (x * 8), (y * 8));
        }

    }


    public class object_00 : Subtype_Object
    {

        public object_00(short id, byte x, byte y, byte size) : base(id,x,y,size)
        {
            int pos = Constants.tile_address + (short)((ROM.DATA[Constants.subtype1_tiles + ((id & 0xFF) * 2) + 1] << 8) + ROM.DATA[Constants.subtype1_tiles + ((id & 0xFF) * 2)]);
            addTiles(4, pos);
            name = "Ceiling";
            if (size == 0)
            {
                size = 32;
            }
        }

        public override void Draw()
        {
            for (int s = 0; s < size; s++)
            {
                draw_tile(tiles[0], (x + s) * 8, y * 8); draw_tile(tiles[2], (x + 1 + s) * 8, y * 8);
                draw_tile(tiles[1], (x + s) * 8, (y+1) * 8); draw_tile(tiles[3], (x + 1 + s) * 8, (y +1) * 8);
                
            }
            Console.WriteLine(tiles[0].id);
        }
    }

    public class object_01 : Subtype_Object
    {

        public object_01(short id, byte x, byte y, byte size) : base(id, x, y, size)
        {
            int pos = Constants.tile_address + (short)((ROM.DATA[Constants.subtype1_tiles + ((id & 0xFF) * 2) + 1] << 8) + ROM.DATA[Constants.subtype1_tiles + ((id & 0xFF) * 2)]);
            addTiles(8, pos);
            name = "Top Wall Horiz.";
            if (size == 0)
            {
                size = 32;
            }
            
        }

        public override void Draw()
        {
            for (int s = 0; s < size; s++)
            {
                draw_tile(tiles[0], (x + (s * 2)) * 8, (y + 0) * 8); draw_tile(tiles[4], (x + 1 + (s * 2)) * 8, (y + 0) * 8);
                draw_tile(tiles[1], (x + (s * 2)) * 8, (y + 1) * 8); draw_tile(tiles[5], (x + 1 + (s * 2)) * 8, (y + 1) * 8);
                draw_tile(tiles[2], (x + (s * 2)) * 8, (y + 2) * 8); draw_tile(tiles[6], (x + 1 + (s * 2)) * 8, (y + 2) * 8);
                draw_tile(tiles[3], (x + (s * 2)) * 8, (y + 3) * 8); draw_tile(tiles[7], (x + 1 + (s * 2)) * 8, (y + 3) * 8);
            }

        }
    }

    public class object_02 : Subtype_Object
    {

        public object_02(short id, byte x, byte y, byte size) : base(id, x, y, size)
        {
            int pos = Constants.tile_address + (short)((ROM.DATA[Constants.subtype1_tiles + ((id & 0xFF) * 2) + 1] << 8) + ROM.DATA[Constants.subtype1_tiles + ((id & 0xFF) * 2)]);
            addTiles(8, pos);
            name = "Bottom Wall Horiz.";
            if (size == 0)
            {
                size = 32;
            }
        }

        public override void Draw()
        {
            for (int s = 0; s < size; s++)
            {
                draw_tile(tiles[0], (x + (s * 2)) * 8, (y + 0) * 8); draw_tile(tiles[4], (x + 1 + (s * 2)) * 8, (y + 0) * 8);
                draw_tile(tiles[1], (x + (s * 2)) * 8, (y + 1) * 8); draw_tile(tiles[5], (x + 1 + (s * 2)) * 8, (y + 1) * 8);
                draw_tile(tiles[2], (x + (s * 2)) * 8, (y + 2) * 8); draw_tile(tiles[6], (x + 1 + (s * 2)) * 8, (y + 2) * 8);
                draw_tile(tiles[3], (x + (s * 2)) * 8, (y + 3) * 8); draw_tile(tiles[7], (x + 1 + (s * 2)) * 8, (y + 3) * 8);
            }
        }
    }
}
