﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace ZeldaFullEditor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {




        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openRomFileDialog.ShowDialog();
        }

        private void openRomFileDialog_FileOk(object sender, CancelEventArgs e)
        {
            FileStream fs = new FileStream(openRomFileDialog.FileName,FileMode.Open ,FileAccess.Read );
            ROM.DATA = new byte[fs.Length];
            fs.Read(ROM.DATA, 0, (int)fs.Length);
            fs.Close();
            byte[] bpp3data = Compression.DecompressTiles();
            byte[] data = Compression.bpp3tobpp4(bpp3data);
            GFX.load4bpp(data, new byte[] { }, 0);
            GFX.LoadDungeonPalette(0);
            GFX.create_gfxs();
            //GFX.load4bpp2(data);
            

            pictureBox1.Image = new Bitmap(512, 512);
            GFX.graphic = Graphics.FromImage(pictureBox1.Image);

            Room room = new Room(97);
            room.Draw();

            foreach(Subtype_Object o in room.tilesObjects)
            {
                listBox1.Items.Add(o.id.ToString());
            }
            foreach (Subtype_Object o in room.layouttilesObjects)
            {
                listBox1.Items.Add(o.id.ToString());
            }

            //pictureBox1.Image = GFX.blocksets[4];


            pictureBox1.Refresh();



            /* FileStream fw = new FileStream("gfx.bin", FileMode.Create, FileAccess.Write);
             fw.Write(data, 0, data.Length);
             fw.Close();*/

        }
    }
}
