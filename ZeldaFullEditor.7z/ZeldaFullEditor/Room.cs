﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZeldaFullEditor
{
    class Room
    {
        int index;
        int header_location;
        byte layout;
        byte floor1;
        byte floor2;
        byte blockset;
        byte spriteset;
        byte palette;
        byte collision; //Need a better name for that
        byte bg2; //TODO : struct
        byte effect;//TODO : struct
        byte tag1;//TODO : struct
        byte tag2;//TODO : struct
        byte holewarp;
        byte staircase1;
        byte staircase2;
        byte staircase3;
        byte staircase4;
        bool light;
        byte holewarp_plane;
        byte staircase1_plane;
        byte staircase2_plane;
        byte staircase3_plane;
        byte staircase4_plane;
        byte messageid;
        bool damagepit;
        public List<Subtype_Object> tilesObjects = new List<Subtype_Object>();
        public List<Subtype_Object> layouttilesObjects = new List<Subtype_Object>();

        public Room(int index)
        {
            this.index = index;
            loadHeader();
            loadTilesObjects();
        }

        public void loadTilesObjects()
        {
            //adddress of the room objects
            int tile_address = (ROM.DATA[Constants.room_object_pointers + 2 + (index * 3)] << 16) +
                (ROM.DATA[(Constants.room_header_pointers + 1) + (index * 3)] << 8) +
                ROM.DATA[(Constants.room_header_pointers) + (index * 3)];

            int objects_location = Addresses.snestopc(tile_address);

            floor1 = (byte)(ROM.DATA[objects_location] & 0x0F);
            floor2 = (byte)((ROM.DATA[objects_location] >> 4) & 0x0F);

            layout = (byte)((ROM.DATA[objects_location + 1] >> 2) & 0x07);

            int layout_address = (ROM.DATA[Constants.room_object_layout_pointers + 2 + (layout * 3)] << 16) +
    (ROM.DATA[(Constants.room_object_layout_pointers + 1) + (layout * 3)] << 8) +
    ROM.DATA[(Constants.room_object_layout_pointers) + (layout * 3)];
            int layout_location = Addresses.snestopc(layout_address);


            int pos = layout_location;

            byte b1 = 0;
            byte b2 = 0;
            byte b3 = 0;
            byte posX = 0;
            byte posY = 0;
            byte sizeX = 0;
            byte sizeY = 0;
            byte sizeXY = 0;
            short oid = 0;
            int layer = 0;
            bool door = false;
            bool endRead = false;
            bool drawlayout = true;
            bool fix = true;
            while (endRead == false)
            {
                if (drawlayout == true)
                {
                    b1 = ROM.DATA[pos];
                    b2 = ROM.DATA[pos + 1];
                    fix = false;
                    if (b1 == 0xFF && b2 == 0xFF)
                    {
                        pos = objects_location + 2;
                        drawlayout = false;
                        //endRead = true;
                        continue;
                    }
                    b3 = ROM.DATA[pos + 2];
                    pos += 3; //we jump to layer2

                    if (b1 >= 0xF8 && b1 < 0xFC) //subtype3 (scalable x,y)
                    {
                        oid = b3;
                        posX = (byte)((b1 & 0xFC) >> 2);
                        posY = (byte)((b2 & 0xFC) >> 2);
                        sizeX = (byte)((b1 & 0x03));
                        sizeY = (byte)((b2 & 0x03));
                        sizeXY = (byte)(((sizeX << 2) + sizeY));

                    }
                    else if (b1 >= 0xFC) //subtype2 (not scalable? )
                    {

                        oid = (short)((b3 & 0x3F) + 0x100);

                        posX = (byte)(((b2 & 0xF0) >> 4) + ((b1 & 0x3) << 4));
                        posY = (byte)(((b2 & 0x0F) << 2) + ((b3 & 0xC0) >> 6));

                        sizeX = 0;
                        sizeY = 0;
                        sizeXY = 0;
                    }
                    else //subtype1
                    {
                        //3rd byte = object
                        //yyyy yycc	xxxx xxaa
                        oid = b3;
                        posX = (byte)((b1 & 0xFC) >> 2);
                        posY = (byte)((b2 & 0xFC) >> 2);
                        sizeX = (byte)((b1 & 0x03));
                        sizeY = (byte)((b2 & 0x03));
                        sizeXY = (byte)(((sizeX << 2) + sizeY));
                    }
                    tilesObjects.Add(new object_01(oid, posX, posY, sizeXY));
                }
                else
                {
                    b1 = ROM.DATA[pos];
                    b2 = ROM.DATA[pos + 1];
                    fix = true;
                    if (b1 == 0xFF && b2 == 0xFF)
                    {
                        pos += 2; //we jump to layer2
                        layer++;
                        door = false;
                        if (layer == 3)
                        {
                            endRead = true;
                            break;
                        }
                        continue;
                    }

                    if (b1 == 0xF0 && b2 == 0xFF)
                    {
                        pos += 2; //we jump to layer2
                        door = true;
                        continue;
                    }
                    b3 = ROM.DATA[pos + 2];
                    if (door)
                    {
                        pos += 2;

                    }
                    else
                    {
                        pos += 3;
                    }

                    if (door == false)
                    {
                        if (b3 >= 0xF8) //subtype3 (scalable x,y) //  && b3 < 0xFC
                        {
                            oid = (short)((b3 << 4) | 0x80 + (((b2 & 0x03) << 2) + ((b1 & 0x03))));
                            //Console.WriteLine(oid.ToString("X4"));
                            posX = (byte)((b1 & 0xFC) >> 2);
                            posY = (byte)((b2 & 0xFC) >> 2);
                            sizeX = (byte)((b1 & 0x03));
                            sizeY = (byte)((b2 & 0x03));
                            sizeXY = (byte)(((sizeX << 2) + sizeY));
                            //Subtype 3, | 0xFXX 

                        }
                        else //subtype1
                        {
                            //3rd byte = object
                            //yyyy yycc	xxxx xxaa
                            oid = b3;
                            posX = (byte)((b1 & 0xFC) >> 2);
                            posY = (byte)((b2 & 0xFC) >> 2);
                            sizeX = (byte)((b1 & 0x03));
                            sizeY = (byte)((b2 & 0x03));
                            sizeXY = (byte)(((sizeX << 2) + sizeY));
                            //subtype1 == XX

                        }
                        if (b1 >= 0xFC) //subtype2 (not scalable? )
                        {
                            //Console.WriteLine(oid.ToString("X4"));
                            oid = (short)((b3 & 0x3F) + 0x100);

                            posX = (byte)(((b2 & 0xF0) >> 4) + ((b1 & 0x3) << 4));
                            posY = (byte)(((b2 & 0x0F) << 2) + ((b3 & 0xC0) >> 6));

                            sizeX = 0;
                            sizeY = 0;
                            sizeXY = 0;
                            //subtype2 = 1XX
                        }

                        tilesObjects.Add(new object_01(oid, posX, posY, sizeXY));
                        //listBox1.Items.Add("(L:" + layer.ToString() + ") T:" + oid.ToString("X3") + " X:" + posX + ", Y:" + posY + " S:" + sizeXY);

                    }
                    else
                    {

                        continue;
                    }
                }

            }
        }

        public void Draw()
        {
            foreach(Subtype_Object o in layouttilesObjects)
            {
                o.Draw();
                
            }

            foreach (Subtype_Object o in tilesObjects)
            {
                o.Draw();
            }
        }


        public void loadHeader()
        {
            //address of the room header
            int address = (ROM.DATA[Constants.room_header_pointers_bank] << 16) +
                            (ROM.DATA[(Constants.room_header_pointers + 1)+ (index * 2)] << 8) +
                            ROM.DATA[(Constants.room_header_pointers) + (index*2)];

            header_location = Addresses.snestopc(address);

            bg2 = (byte)((ROM.DATA[header_location] >> 5) & 0x07);
            collision = (byte)((ROM.DATA[header_location] >> 2) & 0x07);
            light = (((ROM.DATA[header_location]) & 0x01) == 0 ? true : false);

            palette = (byte)((ROM.DATA[header_location + 1] & 0x3F));
            blockset = (byte)((ROM.DATA[header_location + 2]));
            spriteset = (byte)((ROM.DATA[header_location + 3]));
            effect = (byte)((ROM.DATA[header_location + 4]));
            tag1 = (byte)((ROM.DATA[header_location + 5]));
            tag2 = (byte)((ROM.DATA[header_location + 6]));

            holewarp_plane = (byte)((ROM.DATA[header_location + 7]) & 0x03);
            staircase1_plane = (byte)((ROM.DATA[header_location + 7]>>2) & 0x03);
            staircase2_plane = (byte)((ROM.DATA[header_location + 7]>>4) & 0x03);
            staircase3_plane = (byte)((ROM.DATA[header_location + 7]>>6) & 0x03);
            staircase4_plane = (byte)((ROM.DATA[header_location + 8]) & 0x03 );

            holewarp = (byte)((ROM.DATA[header_location + 9]));
            staircase1 = (byte)((ROM.DATA[header_location + 10]));
            staircase2 = (byte)((ROM.DATA[header_location + 11]));
            staircase3 = (byte)((ROM.DATA[header_location + 12]));
            staircase4 = (byte)((ROM.DATA[header_location + 13]));

        }
    }
}
