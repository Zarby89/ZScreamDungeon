﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZeldaFullEditor
{
    [Serializable]
    public static class PotItems_Name
    {
        public static string[] name = new string[]
        {
                "Nothing","Rupee","RockCrab","Bee","Random","Bomb","Heart","Blue Rupee",
"Key","Arrow","Bomb","Heart","Magic","Big Magic","Chicken","Green Soldier","AliveRock?","Blue Soldier",
"Ground Bomb","Heart","Fairy","Heart","Nothing","Hole","Warp","Staircase","Bombable","Switch" };

    }
}
