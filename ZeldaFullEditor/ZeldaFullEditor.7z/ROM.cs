﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZeldaFullEditor
{
    public static class ROM
    {
        public static byte[] DATA;
        public static byte[] IMPORTDATA;
    }
}
